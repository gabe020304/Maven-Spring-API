package com.example.JavaLearning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaLearningApplicationTests {

	@Test
	void contextLoads() {
	}

}
